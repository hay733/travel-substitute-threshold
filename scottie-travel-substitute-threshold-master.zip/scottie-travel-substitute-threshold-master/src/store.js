import { configureStore } from '@reduxjs/toolkit'
import quizreducer from './features/quizSlice'
import answersreducer from "./features/answersSlice";

export const store = configureStore({
  reducer: {
      quiz: quizreducer,
      answers: answersreducer
  },
})