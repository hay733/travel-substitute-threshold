import Quiz from './pages/Quiz'
import About from './pages/About'
import Home from './pages/Home'
import Results from './pages/Results'
import { Route } from 'react-router-dom'
import QuestionsKnowMental from './pages/question pages/QuestionsKnowMental'
import QuestionsUsability from './pages/question pages/QuestionsUsability'
import Descriptions from './pages/ConstructDescriptions'
import QuestionsSSAPerformance from './pages/question pages/QuestionsSSAPerformance'

function App() {
  return (
    <div className="App">
      {/* Main Pages */}
      <Route exact path="/" component={Home} />
      <Route exact path="/about" component={About} />
      <Route exact path="/quiz" component={Quiz} />
      <Route exact path="/results" component={Results} />
      <Route exact path="/descriptions" component={Descriptions} />
      {/* quiz question pages */}
      <Route exact path="/questions-knowledge_mentalWorkload" component={QuestionsKnowMental} />
      <Route exact path="/questions-usability" component={QuestionsUsability} />
      <Route exact path="/questions-ssa_performance" component={QuestionsSSAPerformance} />
    </div>
  );
}
export default App;
