import { initializeApp } from 'firebase/app';
import { getAnalytics } from "firebase/analytics";
import { getAuth, signInAnonymously} from "firebase/auth";

import { 
    addDoc,
    collection,
    getFirestore,
    serverTimestamp
} from "firebase/firestore";

// Safe to expose https://stackoverflow.com/questions/37482366/is-it-safe-to-expose-firebase-apikey-to-the-public
const firebaseConfig = {
    apiKey: "AIzaSyByXwna_4k6lmQXfPYGULrnV6Z5LBsAiM4",
    authDomain: "travel-substitution-threshold.firebaseapp.com",
    databaseURL: "https://travel-substitution-threshold-default-rtdb.firebaseio.com",
    projectId: "travel-substitution-threshold",
    storageBucket: "travel-substitution-threshold.appspot.com",
    messagingSenderId: "864874589617",
    appId: "1:864874589617:web:69ff61298092282a74e190",
    measurementId: "G-YH3BSFJFP2"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);


export const authenticateAnonymously = () => {
    return signInAnonymously(getAuth(app));
};

export const createResponsesRecord = (
        userId,
        quiz,
        initialQuiz,
        answers,
        attendancePlan
    ) => {
    const responsesRecordRef = collection(db, 'responses')
    return addDoc(responsesRecordRef, {
            created: serverTimestamp(),
            createdBy: userId,
            quiz: quiz,
            initialQuiz: initialQuiz,
            answers: answers,
            attendancePlan: attendancePlan
        });
};

export {app, analytics};