import React from 'react';
import { Prompt } from 'react-router'
import { connect } from "react-redux";
import { Link } from 'react-router-dom';

import Header from './Header'
import { renderRecommendation } from '../util';
import {setDegree} from "../features/quizSlice";
import {createResponsesRecord} from "../firebase";
import ResultsTable from './components/ResultsTable';
import {getVisitorFingerprint} from "../fingerprint";

import Tooltip from '@mui/material/Tooltip';
import Dialog from "@material-ui/core/Dialog";
import IconButton from '@mui/material/IconButton';
import { Select, MenuItem } from '@material-ui/core';
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import { withStyles, Button } from "@material-ui/core"
import DialogContentText from "@material-ui/core/DialogContentText";

/**
 * sets the css styles for the container sizes
 */
// const useStyles = makeStyles(() => ({
//     container: {
//         // backgroundColor: "#545F66", // for testing/sizing
//         marginLeft: 5,
//         width: "99%",
//         height: 570,
//         display: "inline-block",
//         marginTop: 100,
//     },
//     content_container: {
//         margin: "10%",
//         height: "99.8%",
//         scrollbarColor: "blue",
//     },
// }));

/**
 * sets the css styles for the different components
 */
const styles = theme => ({
    mainWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "37px",
        margin: "25px",
        textAlign: "center",
        color: "#1E2124",
    },
    buttonStyles: {
        fontFamily: "Open Sans, sans-serif", 
        color: "#1E2124",
        fontWeight: 700,
        fontSize: 17,
        borderColor: "#25292D",
        borderBottomWidth: "1px",
        textTransform: "lowercase",
      },
      link: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "17px",
        textTransform: "lowercase",
        color: "#1E2124",
    },
});

/**
 * renders the result + table + next steps buttons
 */
class Results extends React.Component {
    //handles the change in state
    state = {
        isOpen: false,
        isActive: false,
        knowledgeIsOpen: false,
        mwIsOpen: false,
        usabilityIsOpen: false,
        SSAIsOpen: false,
        performanceIsOpen: false,
        dataContributedPopup: false,
        openModal: false,
        title: null,
        definition: null,
        planningSelectValue: "",
        savingResults: false,
        resultsSaved: false,
        initialQuizResults: undefined
    };

    // Todo: Add alert when user reloads page: https://stackoverflow.com/questions/32841757/detecting-user-leaving-page-with-react-router


    componentDidMount = () => {
        this.setState({
            initialQuizResults: {...this.props.quiz}
        })
    }

    shareResults = async(attendancePlan) => {
        this.setState({
            savingResults: true
        });
        let fingerprint = undefined;
        try {
            fingerprint = await getVisitorFingerprint();
        }
        catch(e) {
            console.error(e);
        }

        let convertedQuiz = {...this.props.quiz};
        if(true) {
            for (const property in this.props.quiz) {
                convertedQuiz[property] = renderRecommendation(this.props.quiz[property]);
              }
        }

        try {
            await createResponsesRecord(
                fingerprint || -1, 
                convertedQuiz, 
                this.state.initialQuizResults, 
                this.props.answers, 
                attendancePlan
            );
        }
        catch(e) {}
        

        this.setState({
            savingResults: false,
            resultsSaved: true
        });
    }

    //shows the table
    handleShow = () => {
        this.setState({isActive: true});
    };
    
    //hides the table
    handleHide = () => {
        this.setState({isActive: false});
    };

    // /**
    //  * Opens the popup of the corresponding table cell
    //  * NOTE: does not open popup when a "degree" button is clicked
    //  * @param {*} e 
    //  */
    // openModal = (e) => {
    //     this.definition = e.target;
    //     if (e.target.innerText.includes("Knowledge") || e.target.innerText.includes("Mental Workload") || e.target.innerText.includes("Usability") || e.target.innerText.includes("Situational") || e.target.innerText.includes("Performance")) {
    //         this.setState({isOpen: true});
    //         var titleString = e.target.innerHTML;
    //         this.title = titleString.substring(0, titleString.indexOf('<'));
    //         var definitionStr = e.target.innerHTML;
    //         // //descriptionStr = descriptionStr.substring(0, descriptionStr.indexOf('<p>' + 1));
    //         definitionStr = definitionStr.replace('<br>', '');
    //         definitionStr = definitionStr.replace('<br>', '');
    //         definitionStr = definitionStr.replace(this.title, '');
    //         this.definition = definitionStr.substring(definitionStr.indexOf('>') + 1, definitionStr.lastIndexOf('<'));
    //     }
    // }
    /**
     * Opens the popup of the knowledge construct
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
    openKnowledgeModal = () => {
        this.setState({knowledgeIsOpen: true});
    }
    /**
     * Closes the popup 
     */
    closeModal = () => {
        this.setState({isOpen: false});
    }
    /**
     * Contributes the user's data when clicked
     */
    contributeData = () => {
        this.setState({dataContributedPopup: true});
    }
    closeContributeData = () => {
        this.setState({dataContributedPopup: false});
    }

    handlePlanningSelectChange = (event) => {
        this.setState({
            planningSelectValue: event.target.value
        })
    }

    render () {
        const { classes } = this.props;
        return (
            <>
                <Prompt
                    when={!this.state.resultsSaved}
                    message='You have not selected how you plan to attend this meeting, are you sure you want to leave?'
                />
                <div style={{display: "flex", flexDirection: "column"}}>
                    {/* Render header and best option */}
                    <Header />
                    <h1 className={classes.mainWords} style = {{marginTop: "150px"}}>Your best option is...</h1>

                    {/* Render the datatable, and have onClick to open popups */}
                    <div className={classes.content_container} style={{margin: "30px"}} /*onClick={this.openModal}*/>
                        <ResultsTable setDegree={this.props.setDegree}/>
                    </div>
                    {/* generates the construct def popup */}
                    <Dialog open={this.state.isOpen} onClose={this.closeModal} maxWidth='md' fullWidth={true}>
                        <DialogTitle margin='10%' align='center' style={{fontFamily:'Open Sans, sans-serif'}}>{this.title}</DialogTitle>
                        <DialogContent>
                            <DialogContentText margin='10%' align='center'>
                                {this.definition}
                            </DialogContentText>
                        </DialogContent>
                        <Button onClick={this.closeModal}>Close</Button>
                    </Dialog>   
                    {/* Render a link to the appendix*/} 
                    <div style={{textAlign: "center"}}>
                        <Link to='/descriptions' className={classes.link}>Learn more about how we determine our Recommendations</Link>
                    </div>

                    <hr style={{width: "100%", borderTop: "1px solid black"}}/>

                    <div style={{display: "flex", flexDirection: "column", justifyContent: "center"}}>
                        <div style={{display: "flex", justifyContent: "center"}}>
                            <h1 className={classes.mainWords}>Last question: How do you plan to attend this meeting?</h1>
                            <Tooltip title="(Help improve the research by answering the question below)" placement="right">
                                <IconButton>
                                    &#9432;
                                </IconButton>
                            </Tooltip>
                        </div>
                        
                        { /* Add Modal */}
                        <div style={{display: "flex", justifyContent: "center", gap: "15px"}}>
                            <Select
                                value={this.state.planningSelectValue}
                                label="Not Answered"
                                onChange={this.handlePlanningSelectChange}
                                style={{minWidth: "100px", width: "10%", maxWidth: "200px"}}
                            >
                                <MenuItem value={"In-Person"}>In-Person</MenuItem>
                                <MenuItem value={"Virtually"}>Virtually</MenuItem>
                                <MenuItem value={"Unsure"}>Unsure</MenuItem>
                            </Select>
                            <Button /*loading={this.state.savingResults}*/ variant="contained" onClick={() => this.shareResults(this.state.planningSelectValue)}>Share Your Results With Us</Button>
                        </div>
                    </div>
                    <div>
                        
                    </div>
                </div>
                <br></br>
          </>
        );
    }
}

const mapStateToProps = (state) => ({
    quiz: state.quiz,
    answers: state.answers
});

const mapDispatchToProps = { setDegree };

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(Results));