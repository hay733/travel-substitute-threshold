import React from 'react'
import { useDispatch } from 'react-redux'

import Radio from '@mui/material/Radio';
import Divider from '@mui/material/Divider';
import Dialog from "@material-ui/core/Dialog";
import { styled } from '@mui/material/styles';
import Checkbox from '@material-ui/core/Checkbox'
import RadioGroup from '@mui/material/RadioGroup';
import FormLabel from '@material-ui/core/FormLabel'
import FormGroup from '@material-ui/core/FormGroup'
import FormControl from '@material-ui/core/FormControl'   
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import FormHelperText from '@material-ui/core/FormHelperText'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import { makeStyles, Typography, Button } from "@material-ui/core"
import DialogContentText from "@material-ui/core/DialogContentText";

import { setDegree } from '../../features/quizSlice';
import { setAnswer } from '../../features/answersSlice';

/**
 * constant that sets the styling for different types of text
 */
const useStyles = makeStyles(() => ({
    questionWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "27px",
        color: "#1E2124",
    },
    answerWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "25px",
        color: "#1E2124",
    },

    divWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "23px",
        color: "#1E2124",
    },
    
    warningWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 500,
        fontSize: "20px",
        letterSpacing: 0,
        color: "#1E2124",
    },
}));

/**
 * sets styling for the dividers
 */
const Root = styled('div')(({ theme }) => ({
    width: '100%',
    ...theme.typography.body2,
    '& > :not(style) + :not(style)': {
      marginTop: theme.spacing(2),
    },
  }));

  /**
   * sets the styling for the question boxes
   */
const themeStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      fontFamily: "Open Sans, sans-serif",
    },
    formControl: {
      margin: theme.spacing(3),
    },
    label: {
        fontFamily: "Open Sans, sans-serif",
        fontSize: "60px",
    }
}));

/**
 * @returns all the rendered questions and answers + dividers
 */
function KnowledgeMentalWorkloadQuestions() {
    //text styles call
    const { questionWords, answerWords,divWords, warningWords } = useStyles();
    //questions style call
    const classes = themeStyles();
    //creates all the default values for the answers
    const [state, setState] = React.useState({
        q1a1: false, q1a2: false, q1a3: false, q1a4: false, q1a5: false, // What is the goal/focus of this meeting?  
        q2: null, // How difficult will (teaching/decision/discussion) meeting tasks be? 
        
        q3: null, // How easy will it be for the participant to remember the content of the meeting?
        q4: null, // How long will it take most participants to accomplish the goals of the meeting?
        q5: null, // How knowledgeable are most participants about the meeting topic? 
        knowledgeIsOpen: false, mwIsOpen: false,
    });

    /**
     * updates knowledge and workload every time theres a state change
     */
    React.useEffect(() => {
        setKnowledge();
        setMentalWorkload();
    });

    //handles question box toggle changes
    const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
        dispatch(setAnswer({section: "knowledge", questionId: event.target.name, answer: event.target.checked}));
        // console.log(event.target.name);
        // console.log(event.target.checked);
    };

    const handleRadioChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
        dispatch(setAnswer({section: "knowledge", questionId: event.target.name, answer: event.target.value}));
        // console.log(event.target.name);
        // console.log(event.target.value);
    };

    //sets the values for the select multiple question
    const { 
        q1a1, q1a2, q1a3, q1a4, q1a5, // What is the goal/focus of this meeting?  
    } = state;

    /**
     * Opens the popup of the knowledge construct
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
    const openKnowledgeModal = (e) => {
        state.title = e.target.outerText; 
        setState({knowledgeIsOpen: true});
    }
    /**
     * Opens the popup of the mental workload construct
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
     const openMwModal = (e) => {
        setState({mwIsOpen: true});
    }
    /**
     * Closes the popup 
     */
    const closeModal = () => {
        setState({isOpen: false});
    }

    const dispatch = useDispatch()

    //set knowledge slice for results table
    const setKnowledge = () => {
        var newDegree, low;
        low = 0;

        //q1, high and medium take precedence over low
        if (state.q1a5 === true || state.q1a4 === true
            || state.q1a3 === true 
            || state.q2 === "q2a2" || state.q2 === "q2a3") { //and q2
            newDegree = "Virtual Reality or Face-to-Face";
        }
        else    
            low++;
        //q2
        if (state.q2 === "q2a1") {
            low++;
        }
        
        //set newDegree low and med
        if (low >= 1 && newDegree !== "Virtual Reality or Face-to-Face") 
            newDegree = "Teleconference";

        dispatch(setDegree({section: "knowledge", degree: newDegree}));
        // console.log(newDegree);
    };

    //set mental_workload slice for results table
    const setMentalWorkload = () => {
        var newDegree, low, high, med;
        low = med = high = 0;

        //q3
        if (state.q3 === "q3a3") {
            low++;
        }
        else if (state.q3 === "q3a2")
            med++;
        else //q3a1
            high++;
        //q4
        if (state.q4 === "q4a3")
            low++;
        else if (state.q4 === "q4a2")
            med++;
        else //q4a1
            high++;
        //q5
        if (state.q5 === "q5a1")
            low++;
        else if (state.q5 === "q5a2")
            med++;
        else //q5a3
            high++;

        //set newDegree low and med
        if (low >= med && low >= high) 
            newDegree = "Teleconference";
        else if (med >= high) 
            newDegree = "Virtual Reality";
        else 
            newDegree = "Face-to-Face"

        dispatch(setDegree({section: "mental_workload", degree: newDegree}));
    };

    return(
        <Root>
        <div>

            <Divider textAlign="right" className={divWords} onClick={openKnowledgeModal}>knowledge &#9432;</Divider>
            {/* What is the goal/focus of this meeting?   */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">What is the goal/focus of this meeting?</FormLabel>
                    <br></br>
                    <FormGroup>
                        <FormControlLabel
                            control={<Checkbox checked={q1a1} onChange={handleChange} name="q1a1" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>to be introduced to new people or a new team</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a2} onChange={handleChange} name="q1a2" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>to share information</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a3} onChange={handleChange} name="q1a3" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>to discuss</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a4} onChange={handleChange} name="q1a4" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>to make a decision</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a5} onChange={handleChange} name="q1a5" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>to teach</Typography>}
                        />
                    </FormGroup>
                    <FormHelperText className={warningWords}>Choose all that apply</FormHelperText>
                </FormControl>
            </div>
            {/* How difficult will (teaching/decision/discussion) meeting tasks be?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl} name="quiz">
                    <FormLabel className={questionWords} component="legend">How difficult will meeting tasks be? **</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q2">
                        <FormControlLabel
                            value="q2a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>low</Typography>}
                        />
                        <FormControlLabel
                            value="q2a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>medium</Typography>}
                        />
                        <FormControlLabel
                            value="q2a3" control={<Radio onChange={handleRadioChange}/>} 
                            label={<Typography className={answerWords}>high</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>

            <Divider textAlign="right" className={divWords} onClick={openMwModal}>mental workload &#9432;</Divider>
            {/* How easy will it be for the participant to remember the content of the meeting? */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How easy will it be for the participant to remember the content of the meeting?</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q3">
                        <FormControlLabel
                            value="q3a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>the information is easy to remember</Typography>}
                        />
                        <FormControlLabel
                            value="q3a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>they will remember most information without review</Typography>}
                        />
                        <FormControlLabel
                            value="q3a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>they may need to review most of the information later</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How long will it take most participants to accomplish the goals of the meeting? */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How long will it take most participants to accomplish the goals of the meeting?</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q4">
                        <FormControlLabel
                            value="q4a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>1-2 hours</Typography>}
                        />
                        <FormControlLabel
                            value="q4a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>half day (~4 hours)</Typography>}
                        />
                        <FormControlLabel
                            value="q4a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>1+ days</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* //  How knowledgeable are most participants about the meeting topic?   */}
            <div className={classes.root}>
                <br></br><br></br><br></br><br></br><br></br>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How knowledgeable are most participants about the meeting topic?</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q5">
                        <FormControlLabel
                            value="q5a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>they are new to the topic</Typography>}
                        />
                        <FormControlLabel
                            value="q5a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>this is a review</Typography>}
                        />
                        <FormControlLabel
                            value="q5a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>they are experts</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
        </div>
        {/* knowledge popup */}
        <Dialog open={state.knowledgeIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Knowledge</DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                How well the participant retains learned knowledge about the topic of discussion. 
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        {/* mental worklaod popup */}
        <Dialog open={state.mwIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Mental Workload</DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                The ease of mental effort that the participants need to expend to carry out the purpose of the meeting without overloading the participant. 
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        </Root>
    );
}

export default KnowledgeMentalWorkloadQuestions;