import React from 'react'
import { useDispatch } from 'react-redux'

import Radio from '@mui/material/Radio';
import Divider from '@mui/material/Divider';
import Dialog from "@material-ui/core/Dialog";
import { styled } from '@mui/material/styles';
import Checkbox from '@material-ui/core/Checkbox'
import FormLabel from '@material-ui/core/FormLabel'
import RadioGroup from '@mui/material/RadioGroup';
import FormGroup from '@material-ui/core/FormGroup'
import FormControl from '@material-ui/core/FormControl'   
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import FormHelperText from '@material-ui/core/FormHelperText'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import { makeStyles, Typography, Button } from "@material-ui/core"
import DialogContentText from "@material-ui/core/DialogContentText";

import { setDegree } from '../../features/quizSlice';
import { setAnswer } from '../../features/answersSlice';

/**
 * constant that sets the styling for different types of text
 */
const useStyles = makeStyles(() => ({
    questionWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "27px",
        color: "#1E2124",
    },
    answerWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "25px",
        color: "#1E2124",
    },

    divWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "23px",
        color: "#1E2124",
    },
    
    warningWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 500,
        fontSize: "20px",
        letterSpacing: 0,
        color: "#1E2124",
    },
}));

/**
 * sets styling for the dividers
 */
const Root = styled('div')(({ theme }) => ({
    width: '100%',
    ...theme.typography.body2,
    '& > :not(style) + :not(style)': {
      marginTop: theme.spacing(2),
    },
  }));

  /**
   * sets the styling for the question boxes
   */
const themeStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      fontFamily: "Open Sans, sans-serif",
    },
    formControl: {
      margin: theme.spacing(3),
    },
    label: {
        fontFamily: "Open Sans, sans-serif",
        // fontWeight: 700,
        fontSize: "60px",
    }
}));

/**
 * @returns all the rendered questions and answers + dividers
 */
function UsabilityQuestions() {
    //text styles call
    const { questionWords, answerWords,divWords, warningWords } = useStyles();
    //questions style call
    const classes = themeStyles();
    //creates al the default values for the answers
    const [state, setState] = React.useState({
        q1a1: false, q1a2: false, q1a3: false, q1a4: false, q1a5: false, // What will you need to access in order to meet the goals of your meeting? 
        q2: null, // Do all participants have access to the necessary equipment for VR/AR?
        q3: null, // Do all participants have access to the necessary equipment for Zoom? 
        q4: null, // How skilled are the participants at using the Zoom platform?
        q5: null, // How skilled are the participants at using the AR/VR? 
        q6: null, // How skilled are most participants at communicating?
        q7: null, // How much training will the participants need to be up to date with the technologies used? 
        q8: null, // Do all participants have a reliable broadband connection? 
        q9: null, // How feasible is it for participants to travel? 
        q10: null, // Can all participants travel? 

        q11: null, // How easy will it be for most participants to accomplish the task? 
        isOpen: false
    });

    //sets the questions
    const { 
        q1a1, q1a2, q1a3, q1a4, q1a5, // What will you need to access in order to meet the goals of your meeting? 
    } = state;

    //handles question box toggle changes
    const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
        dispatch(setAnswer({section: "usability", questionId: event.target.name, answer: event.target.checked}));
        // console.log(event.target.name);
        // console.log(event.target.checked);
    };

    /**
     * updates knowledge and workload every time theres a state change
     */
     React.useEffect(() => {
        setUsabilityEOU();
        setUsabilityTA();
    });

    //handles question box toggle changes
    const handleRadioChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
        dispatch(setAnswer({section: "usability", questionId: event.target.name, answer: event.target.value}));
        // console.log(event.target.name);
        // console.log(event.target.value);
    };

    //allows us to set the slices
    const dispatch = useDispatch()

    /**
     * sets the Usability EOU slice value ISNT WORKING RN
     */
     const setUsabilityEOU = () => {
        var newDegree, low, high, med;
        low = med = high = 0;

        //q1
        if (state.q1a1 === true) {
            low++;
        }
        if (state.q1a2 === true || state.q1a3 === true) {
            med++;
            low++;
        }
        if (state.q1a4 === true || state.q1a5 === true)
            high++;
        //q2 and q3
        if (state.q2 === "q2a1") {
            low++;
            med++;
            high++;
        }
        else if (state.q2 === "q2a2" && state.q3 === "q3a2") //no vr or zoom, need f2f OVERRIDE ALL
            newDegree = "Face-to-Face Only"
        else if (state.q2 === "q2a2") {
            med++;
            low++;
            newDegree = "Face-to-Face or Teleconference Only"
        }
        else if (state.q3 === "q3a1") {
            high++;
            low++;
            med++;
        }
        //q4
        if (state.q4 === "q4a1") {
            med++;
            high++;
        }
        else if (state.q4 === "q4a2" || state.q4 === "q4a2") //q4a3 or q4a2
            low++;
        //q5
        if (state.q5 === "q5a1") {
            low++;
            med++;
        }
        else if (state.q5 === "q5a2" || state.q5 === "q5a3")
            high++;
        //q6
        if (state.q6 === "q6a1")
            med++;
        else if (state.q6 === "q6a2")
            high++;
        else if (state.q6 === "q6a3")
            low++;
        //q7
        if (state.q7 === "q7a1")
            low++;
        else if (state.q7 === "q7a2" || state.q7 === "q7a3") {
            med++;
            high++;
        }
        //q8
        if (state.q8 === "q8a1") {
            low++;
            high++;
        }
        else if (state.q8 === "q8a2")
            med++;
        //q9
        if (state.q9 === "q9a1" || state.q9 === "q9a2") {
            high++;
            low++;
        }
        else if (state.q9 === "q9a3" || state.q9 === "q9a4") {
            low++;
            med++;
            high++;
        }
        //q10
        if (state.q10 === "q10a1" || state.q10 === "q10a2") {
            low++;
            high++;
        }
        else if (state.q10 === "q10a3" || state.q10 === "q10a4"){
            low++;
            med++;
            high++;
        }

        //set newDegree
        if (newDegree === "Face-to-Face or Teleconference Only") {
            if (low >= med) //low
                newDegree = "Teleconference, Virtual Reality Impossible";
            else //med
                newDegree = "Face-to-Face, Virtual Reality Impossible";
        }
        else if (newDegree !== "Face-to-Face Only") {
            if (low >= med && low >= high) //low
                newDegree = "Teleconference";
            else if (med >= high) //med
                newDegree = "Face-to-Face";
            else if (high > med && high > low) //high
                newDegree = "Virtual Reality";
        }

        dispatch(setDegree({section: "usability_eau", degree: newDegree}));
        // console.log(newDegree);
        // console.log(low);
        // console.log(med);
        // console.log(high);
    };

    /**
     * sets the usability task experience slice value
     */
     const setUsabilityTA = () => {
        //q11
        if (state.q11 === "q11a1") { //high
            dispatch(setDegree({section: "usability_te", degree: "Virtual Reality"}));
        }
        else if (state.q11 === "q11a2") { //med
            dispatch(setDegree({section: "usability_te", degree: "Face-to-Face"}));
        }
        else if (state.q11 === "q11a3") { //low
            dispatch(setDegree({section: "usability_te", degree: "Teleconference"}));
        }
    };


    /**
     * Opens the popup of the corresponding table cell
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
     const openUEOUModal = (e) => {
        setState({UEOUIsOpen: true});
    }

    /**
     * Opens the popup of the corresponding table cell
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
     const openUseTaskModal = (e) => {
        setState({UseTaskIsOpen: true});
    }
    /**
     * Closes the popup 
     */
    const closeModal = () => {
        setState({isOpen: false});
    }

    return(
        <Root>
        <div>

            <Divider textAlign="right" className={divWords} onClick={openUEOUModal}>usability - ease of use &#9432;</Divider>
            {/* What will you need to access in order to meet the goals of your meeting? */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">What will you need to access in order to meet the goals of your meeting?</FormLabel>
                    <br></br>
                    <FormGroup>
                        <FormControlLabel
                            control={<Checkbox checked={q1a1} onChange={handleChange} name="q1a1" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>none </Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a2} onChange={handleChange} name="q1a2" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>digital documents</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a3} onChange={handleChange} name="q1a3" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>physical artifacts with no digital representation available</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a4} onChange={handleChange} name="q1a4" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>virtual artifacts (e.g. CAD Models)</Typography>}
                        />
                        <FormControlLabel
                            control={<Checkbox checked={q1a5} onChange={handleChange} name="q1a5" style={{ color: "white" }} />}
                            label={<Typography className={answerWords}>virtual environments</Typography>}
                        />
                    </FormGroup>
                    <FormHelperText className={warningWords}>Choose all that apply</FormHelperText>
                </FormControl>
            </div>
            {/* Do all participants have access to the necessary equipment for VR/AR?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">Do all participants have access to the necessary equipment for VR/AR? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q2">
                        <FormControlLabel
                            value="q2a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>yes</Typography>}
                        />
                        <FormControlLabel
                            value="q2a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>no</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* Do all participants have access to the necessary equipment for Teleconferencing?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">Do all participants have access to the necessary equipment for Teleconferencing? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q3">
                        <FormControlLabel
                            value="q3a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>yes</Typography>}
                        />
                        <FormControlLabel
                            value="q3a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>no</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How skilled are the participants at using the Zoom platform?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How skilled are the participants at using the Zoom platform? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q4">
                        <FormControlLabel
                            value="q4a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>no previous experience</Typography>}
                        />
                        <FormControlLabel
                            value="q4a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>familiar</Typography>}
                        />
                        <FormControlLabel
                            value="q4a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>experienced</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* //  How skilled are the participants at using the AR/VR?   */}
            <div className={classes.root}>
                <br></br><br></br><br></br><br></br><br></br>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How skilled are the participants at using the AR/VR? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q5">
                        <FormControlLabel
                            value="q5a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>no previous experience</Typography>}
                        />
                        <FormControlLabel
                            value="q5a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>familiar</Typography>}
                        />
                        <FormControlLabel
                            value="q5a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>experienced</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How skilled are most participants at communicating? */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How skilled are most participants at communicating?</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q6">
                        <FormControlLabel
                            value="q6a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>low</Typography>}
                        />
                        <FormControlLabel
                            value="q6a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>medium</Typography>}
                        />
                        <FormControlLabel
                            value="q6a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>high</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How much training will the participants need to be up to date with the technologies used?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How much training will the participants need to be up to date with the technologies used?</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q7">
                        <FormControlLabel
                            value="q7a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>none</Typography>}
                        />
                        <FormControlLabel
                            value="q7a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>less than 1 hour</Typography>}
                        />
                        <FormControlLabel
                            value="q7a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>more than 1 hour</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* Do all participants have a reliable broadband connection?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">Do all participants have a reliable broadband connection? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q8">
                        <FormControlLabel
                            value="q8a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>yes</Typography>}
                        />
                        <FormControlLabel
                            value="q8a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>no</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How feasible is it for participants to travel?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How feasible is it for participants to travel? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q9">
                        <FormControlLabel
                            value="q9a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>not possible</Typography>}
                        />
                        <FormControlLabel
                            value="q9a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>low feasibility </Typography>}
                        />
                        <FormControlLabel
                            value="q9a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>medium feasibility </Typography>}
                        />
                        <FormControlLabel
                            value="q9a4" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>high feasibility</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* Can all participants travel?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">Can all participants travel? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q10">
                        <FormControlLabel
                            value="q10a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>none</Typography>}
                        />
                        <FormControlLabel
                            value="q10a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>less than half</Typography>}
                        />
                        <FormControlLabel
                            value="q10a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>at least half</Typography>}
                        />
                        <FormControlLabel
                            value="q10a4" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>all</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
        </div>

        <Divider textAlign="right" className={divWords} onClick={openUseTaskModal}>usability - topic of discussion &#9432;</Divider>
        {/* How easy is the topic of discussion for the participants? */}
        <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How easy is the topic of discussion for the participants?</FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q11">
                        <FormControlLabel
                            value="q11a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>easy</Typography>}
                        />
                        <FormControlLabel
                            value="q11a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>moderate</Typography>}
                        />
                        <FormControlLabel
                            value="q11a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>difficult</Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>

        {/* usability eou popup */}
        <Dialog open={state.UEOUIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Confidence In Immediate Performance</DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                The perceived ease of use of the communication tools to the participants. <br></br>
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        {/* usability task popup */}
        <Dialog open={state.UseTaskIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Usability - topic of discussion </DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                The perceived experience of the task being performed.<br></br>
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        </Root>
    );
}

export default UsabilityQuestions;