import React from 'react'
import { useDispatch } from 'react-redux'

import Radio from '@mui/material/Radio';
import Divider from '@mui/material/Divider';
import Dialog from "@material-ui/core/Dialog";
import { styled } from '@mui/material/styles';
import RadioGroup from '@mui/material/RadioGroup';
import FormLabel from '@material-ui/core/FormLabel'
import FormControl from '@material-ui/core/FormControl'   
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import FormControlLabel from '@material-ui/core/FormControlLabel'
import { makeStyles, Typography, Button } from "@material-ui/core"
import DialogContentText from "@material-ui/core/DialogContentText";

import { setDegree } from '../../features/quizSlice';
import { setAnswer } from '../../features/answersSlice';

/**
 * constant that sets the styling for different types of text
 */
const useStyles = makeStyles(() => ({
    questionWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "27px",
        color: "#1E2124",
    },
    answerWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "25px",
        textTransform: "lowercase",
        color: "#1E2124",
    },

    divWords: {
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "23px",
        color: "#1E2124",
    },
}));

/**
 * sets styling for the dividers
 */
const Root = styled('div')(({ theme }) => ({
    width: '100%',
    ...theme.typography.body2,
    '& > :not(style) + :not(style)': {
      marginTop: theme.spacing(2),
    },
  }));

/**
 * sets the styling for the question boxes
 */
const themeStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      fontFamily: "Open Sans, sans-serif",
    },
    formControl: {
      margin: theme.spacing(3),
    },
    label: {
        fontFamily: "Open Sans, sans-serif",
        fontSize: "60px",
    }
}));

/**
 * @returns all the rendered questions and answers + dividers
 */
function SSAPerformanceQuestions() {
    //text styles call
    const { questionWords, answerWords,divWords } = useStyles();
    //questions style call
    const classes = themeStyles();
    //creates all the default values for the answers
    const [state, setState] = React.useState({
        q1: null, //How important is it that you are looking at the same thing at the same time? 
        q2: null, //How important is it for all participants to comprehend the same concepts at the same time?  
        q3: null, //How important is it for all participants to be able to predict/make the same projections at the same time? 

        q4: null, //How important is it for participants to be confident in performing the tasks described immediately after this meeting?

        q5: null, //How important is it for participants to be confident in performing the tasks described one to two weeks after this meeting?

        SSAIsOpen: false, immediatePerfIsOpen: false, futurePerfIsOpen: false
    });

    /**
     * updates knowledge and workload every time theres a state change
     */
     React.useEffect(() => {
        setSSA();
        setImmedPerformance();
        setFutPerformance();
    });

    //handles question box toggle changes
    const handleRadioChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
        dispatch(setAnswer({section: "ssa", questionId: event.target.name, answer: event.target.value}));
        // console.log(event.target.name); //for testing
        // console.log(event.target.value);
    };

    const dispatch = useDispatch();

    /**
     * sets the SSA slice value
     */
    const setSSA = () => {
        var newDegree, low, high, med;
        low = med = high = 0;

        //q1
        if (state.q1 === "q1a1") {
            low++;
        }
        else if (state.q1 === "q1a2")
            med++;
        else //q1a3
            high++;
        //q2
        if (state.q2 === "q2a1")
            low++;
        else if (state.q2 === "q2a2")
            med++;
        else //q2a3
            high++;
        //q3
        if (state.q3 === "q3a1")
            low++;
        else if (state.q3 === "q3a2")
            med++;
        else //q3a3
            high++;

        //set newDegree
        if (high >= med && high >= low) //high
            newDegree = "Face-to-Face";
        else if (med >= low) //med
            newDegree = "Virtual Reality";
        else //low
            newDegree = "Teleconference";

        dispatch(setDegree({section: "ssa", degree: newDegree}));
        // console.log(newDegree); //for testing
        // console.log(low);
        // console.log(med);
        // console.log(high);
    };

    /**
     * sets the immediate performance slice value
     */
     const setImmedPerformance = () => {
        //q4
        if (state.q4 === "q4a1") { //high
            dispatch(setDegree({section: "immediate_perf", degree: "Virtual Reality"}));
            // console.log("Virtual Reality"); //for testing
        }
        else if (state.q4 === "q4a2") { //med
            dispatch(setDegree({section: "immediate_perf", degree: "Face-to-Face"}));
            // console.log("Face-to-Face"); //for testing
        }
        else if (state.q4 === "q4a3") { //low
            dispatch(setDegree({section: "immediate_perf", degree: "Teleconference"}));
            // console.log("Teleconference"); //for testing
        }
    };

    /**
     * sets the future performance slice value
     */
     const setFutPerformance = () => {
        //q4
        if (state.q5 === "q5a1") { //high
            dispatch(setDegree({section: "future_perf", degree: "Virtual Reality"}));
            // console.log("Virtual Reality"); //for testing
        }
        else if (state.q5 === "q5a2") { //med
            dispatch(setDegree({section: "future_perf", degree: "Face-to-Face"}));
            // console.log("Face-to-Face"); //for testing
        }
        else if (state.q5 === "q5a3") { //low
            dispatch(setDegree({section: "future_perf", degree: "Teleconference"}));
            // console.log("Teleconference"); //for testing
        }
    };

    /**
     * Opens the popup of the corresponding table cell
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
    const openSSAModal = (e) => {
        setState({SSAIsOpen: true});
    }
    /**
     * Opens the popup of the corresponding table cell
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
     const openImmediatePerf = (e) => {
        setState({immediatePerfIsOpen: true});
    }
    /**
     * Opens the popup of the corresponding table cell
     * NOTE: does not open popup when a "degree" button is clicked
     * @param {*} e 
     */
     const openFuturePerf = (e) => {
        setState({futurePerfIsOpen: true});
    }
    /**
     * Closes the popup 
     */
    const closeModal = () => {
        setState({isOpen: false});
    }
    return(
        <Root>
        <div>

            <Divider textAlign="right" className={divWords} onClick={openSSAModal}>shared situational awareness &#9432;</Divider>
            {/* How important is it that you are looking at the same thing at the same time?  */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How important is it that you are looking at the same thing at the same time? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q1">
                        <FormControlLabel
                            value="q1a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Low importance </Typography>}
                        />
                        <FormControlLabel
                            value="q1a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Medium importance </Typography>}
                        />
                        <FormControlLabel
                            value="q1a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>High importance </Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How important is it for all participants to comprehend the same concepts at the same time?   */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How important is it for all participants to comprehend the same concepts at the same time? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q2">
                        <FormControlLabel
                            value="q2a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Low importance </Typography>}
                        />
                        <FormControlLabel
                            value="q2a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Medium importance </Typography>}
                        />
                        <FormControlLabel
                            value="q2a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>High importance </Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            {/* How important is it for all participants to be able to predict/make the same projections at the same time? */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How important is it for all participants to be able to predict/make the same projections at the same time? </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q3">
                        <FormControlLabel
                            value="q3a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Low importance </Typography>}
                        />
                        <FormControlLabel
                            value="q3a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Medium importance </Typography>}
                        />
                        <FormControlLabel
                            value="q3a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>High importance </Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
            <Divider textAlign="right" className={divWords} onClick={openImmediatePerf}>confidence in immediate performance &#9432;</Divider>
            {/* How important is it for participants to be confident in performing the tasks described immediately after this meeting?    */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How important is it for participants to be confident in performing the tasks described immediately after this meeting?  </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q4">
                        <FormControlLabel
                            value="q4a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Low importance </Typography>}
                        />
                        <FormControlLabel
                            value="q4a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Medium importance </Typography>}
                        />
                        <FormControlLabel
                            value="q4a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>High importance </Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>

            <Divider textAlign="right" className={divWords} onClick={openFuturePerf}>confidence in future performance &#9432;</Divider>
            {/* How important is it for participants to be confident in performing the tasks described one to two weeks after this meeting?   */}
            <div className={classes.root}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel className={questionWords} component="legend">How important is it for participants to be confident in performing the tasks described one to two weeks after this meeting?  </FormLabel>
                    <br></br>
                    <RadioGroup aria-labelledby="demo-radio-buttons-group-label" name="q5">
                        <FormControlLabel
                            value="q5a1" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Low importance </Typography>}
                        />
                        <FormControlLabel
                            value="q5a2" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>Medium importance </Typography>}
                        />
                        <FormControlLabel
                            value="q5a3" control={<Radio onChange={handleRadioChange}/>}
                            label={<Typography className={answerWords}>High importance </Typography>}
                        />
                    </RadioGroup>
                </FormControl>
            </div>
        </div>
        {/* Shared Situational Awareness popup */}
        <Dialog open={state.SSAIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Shared Situational Awareness</DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                The extent to which participants have a commonly understood mental model of a situation (I.e., what is currently happening and what is going to happen). 
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        {/* Immediate Performance popup */}
        <Dialog open={state.immediatePerfIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Confidence In Immediate Performance</DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                How confident the participant is in completing the required task(s) immediately after training.<br></br>
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        {/* Future Performance popup */}
        <Dialog open={state.futurePerfIsOpen} onClose={closeModal} maxWidth='md' fullWidth={true}>
            <DialogTitle margin='10%' align='center'>Confidence In Future Performance</DialogTitle>
            <DialogContent>
                <DialogContentText margin='10%' align='center'>
                How confident the participant is in completing the required task(s) 1 to 2 weeks after training.<br></br>
                </DialogContentText>
                </DialogContent>
                <Button onClick={closeModal}>Close</Button>
        </Dialog>
        </Root>
    );
}

export default SSAPerformanceQuestions;