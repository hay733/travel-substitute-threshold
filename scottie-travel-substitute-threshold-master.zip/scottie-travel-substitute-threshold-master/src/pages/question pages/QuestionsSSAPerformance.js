import React from 'react'
import {Link} from 'react-router-dom';

import { Step, Stepper } from "@material-ui/core"
import { withStyles, Button, StepButton } from "@material-ui/core"

import Header from '../Header'
import SSAPerformanceQuestions from '../constructQuestions/SSAPerformance'

/**
 * css constant styles for different components
 * @param {*} theme
 * @returns
 */
const styles = theme => ({
    submitButton: {
      fontFamily: "Open Sans, sans-serif",
      fontWeight: 700,
      fontSize: "25px",
      textTransform: "lowercase",
      color: "#FFFFEE",
      backgroundColor: "#1E2124",
    },
    container: {
        marginLeft: 150,
        width: "85%",
        height: 500,
        marginTop: 100,
        display: "fixed",
    },
    stepper: {
        backgroundColor: "#A2B6E7",
        marginLeft: "-7%",
        color: "black",
        fontFamily: "Open Sans, sans-serif",
        fontWeight: 700,
        fontSize: "30px",
        textTransform: "lowercase",
    }
});

/**
 * renders the questions and the submit button
 * calls the questionBoxes component which renders all the quiz questions
 */
function QuestionsSSAPerformance(props) {
    const [_, setIsOpen] = React.useState(false);
    //const [title, setTitle] = React.useState(null);

    //opens the popup
    const openModal = (e) => {
        setIsOpen(true);
    }
    // //closes the popup
    // const closeModal = () => {
    //     setIsOpen(false);
    // }


    const saveSectionQuestions = () => {

    }

    const { classes} = props;

    return (
        <>
            <Header />
            <body className={classes.container} style={{ fontFamily: "Open Sans, sans-serif"  }}>
                <br></br><br></br>
                <Stepper activeStep={1} nonLinear alternativeLabel className={classes.stepper}>
                    <Step>
                        <StepButton>knowledge & mental workload</StepButton>
                    </Step>
                    <Step>
                        <StepButton>shared situational awareness & performance</StepButton>
                    </Step>
                    <Step>
                        <StepButton>usability</StepButton>
                    </Step>
                </Stepper>

                <SSAPerformanceQuestions onClick={openModal}/>
                <br></br><br></br>

                <Link to="/questions-knowledge_mentalWorkload"><Button className={classes.submitButton}>
                    Back
                </Button></Link>
                <Link to="/questions-usability"><Button className={classes.submitButton} onClick={saveSectionQuestions} style={{float: 'right'}}>
                    Next
                </Button></Link>
                <br></br><br></br><br></br>
            </body>
        </>

    );
}

export default withStyles(styles)(QuestionsSSAPerformance);
