/**
 * These data structures are supposed to represent the results from the experiment. 
 * However, it is not implemented unless a large change is requested since changing existing code is much simpler than 
 * ripping out that system and implementing this single source of truth
 */

/**
 * Modality would be better represented using a bitmask since multiple modalities can be used at once
 */
// export class Modality {
//     static F2F = new Modality("Face-to-Face", 0b00001)
//     static Telecon = new Modality("Teleconference", 0b00010)
//     static VR = new Modality("Virtual Reality", 0b00100)

//     constructor(name, mask) {
//         this.name = name
//         this.mask = mask
//     }

//     toString(mod) {
//         return this.name;
//         // "Face-to-Face"
//         // "Teleconference"
//         // "Virtual Reality"
//     }
// }

/**
 * But could also be represented more simply in an enum like structure
 */
// export const Modality = {
//     F2F: "Face-to-Face",
//     Telecon: "Teleconference",
//     XR: "Extended-Reality"
// }

// export const ConstructLevel = {
//     High: "High",
//     Medium: "Medium",
//     Low: "Low"
// }

// export const Construct = {
//     Knowledge: "Knowledge",
//     SharedSituationalAwareness: "SharedSituationalAwareness",
//     UsabilityEaseOfUse: "UsabilityEaseOfUse",
//     UsabilityTaskExperience: "UsabilityTaskExperience",
//     MentalWorkload: "MentalWorkload",
//     ImmediatePerformance: "ImmediatePerformance",
//     FuturePerformance: "FuturePerformance"
//   };

// export const TST_SCORING = {
//     [Construct.Knowledge]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     },
//     [Construct.SharedSituationalAwareness]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 1,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 1,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     },
//     [Construct.UsabilityEaseOfUse]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     },
//     [Construct.UsabilityTaskExperience]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     },
//     [Construct.MentalWorkload]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     },
//     [Construct.ImmediatePerformance]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     },
//     [Construct.FuturePerformance]: {
//         [ConstructLevel.High]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Medium]: {
//             [Modality.F2F]: 0.5,
//             [Modality.XR]: 0.5,
//             [Modality.Telecon]: 0,
//         },
//         [ConstructLevel.Low]: {
//             [Modality.F2F]: 0,
//             [Modality.XR]: 0,
//             [Modality.Telecon]: 1,
//         },
//     }
// }