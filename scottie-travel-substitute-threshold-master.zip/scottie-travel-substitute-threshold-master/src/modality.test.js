import { Modality } from "./modality";

test("test", () => {
    expect(Modality.F2F.toString()
        ).toBe("Face-to-Face");
})