import FingerprintJS from "@fingerprintjs/fingerprintjs";

FingerprintJS.load();

export const getVisitorFingerprint = async() => {
    return new Promise((resolve, reject) => {
        FingerprintJS.load()
            .then((fp) => fp.get())
            .then((result) => {
                resolve(result.visitorId);
            })
            .catch(e => {
                reject(e);
            })
        }
    )
}