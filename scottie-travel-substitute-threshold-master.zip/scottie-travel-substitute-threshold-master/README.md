## Project for the SCOTTIE research project created by Haylee Lawrence and later maintained by Jameel Kelley
The Travel Substitute Threshold is a site that allows a user to evaluate whether they will have
optimal meeting performance using a Teleconference Software, a Virtual Reality Platform, or a
Face-to-Face meeting.

The TST is hosted on Firebase at this link: https://travel-substitution-threshold.web.app/

### Export Firebase Firestore CSV
#### First Time

#### Every Time After